## Web Week2 examples, CSS and Bootstrap

Live versions here [https://claraj.github.io/week2-examples/](https://claraj.github.io/week2-examples/)
